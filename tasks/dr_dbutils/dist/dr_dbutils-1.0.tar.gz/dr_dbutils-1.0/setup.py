"""
This module exists to keep all database specific code in a single place. The
cursor and connection objects can be imported and used directly, but for most
queries, simply using the "query()" fuction will likely suffice.
"""

from setuptools import setup

setup(
    name='dr_dbutils',
    version='1.0',
    description="Disaster Recovery Database functions",
    author="lpdaac",
    author_email = "lpdaac@usgs.gov",
    url='https://lpdaac.usgs.gov/',
    py_modules=['requests_db', 'database']
)
