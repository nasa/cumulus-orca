from setuptools import setup

setup(
    name='pg_utils',
    version='1.0',
    description="postgres utilities",
    author="lpdaac",
    author_email="lpdaac@usgs.gov",
    url='https://lpdaac.usgs.gov/',
    py_modules=['database', 'db_config']
)
